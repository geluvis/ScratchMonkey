ScratchMonkey
=============

Arduino software programmer sketch, supporting ISP, HVSP, HVPP and TPI.

Licensed under the [BSD License](http://opensource.org/licenses/bsd-license.php)

For details, please consult the [User Manual](http://microtherion.github.com/ScratchMonkey/)
